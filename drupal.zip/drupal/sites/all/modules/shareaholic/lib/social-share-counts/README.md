social-share-counts
===================

A library to check how many times a URL has been shared on Facebook, Twitter, Pinterest, Google+, etc.


Contributing
------------

1. Fork the [official repository](https://github.com/shareaholic/social-share-counts/tree/master).
2. Make your changes in a topic branch.
3. Send a pull request.

Credits
-------

![Shareaholic](https://blog.shareaholic.com/wp-content/uploads/2013/10/new-shareaholic-logo.png)

social-share-counts is maintained and funded by [Shareaholic, Inc](https://shareaholic.com/). The names and logos for Shareaholic are trademarks of Shareaholic, Inc.

Thank you to all [the contributors](https://github.com/shareaholic/social-share-counts/contributors)!


License
-------

social-share-counts is Copyright © 2014 Shareaholic Inc. It is free software, and may be redistributed under the terms specified in the [LICENSE](https://github.com/shareaholic/social-share-counts/blob/master/LICENSE) file.