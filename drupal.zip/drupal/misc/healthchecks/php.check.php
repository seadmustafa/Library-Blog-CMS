<?php
phpinfo(64);
